require("dotenv").config();
const express = require("express");
const mongoose = require("mongoose");
const multer = require("multer");
const { GridFsStorage } = require("multer-gridfs-storage");
const { GridFSBucket } = require("mongodb");

const app = express();
const mongoURI = process.env.MONGO_URI;
const PORT = process.env.PORT || 5000;

// Connect to MongoDB
const conn = mongoose.createConnection(mongoURI, {
  useNewUrlParser: true,
  useUnifiedTopology: true,
});

let gfs;
let gridFSBucket;

conn.once("open", () => {
  gridFSBucket = new mongoose.mongo.GridFSBucket(conn.db, {
    bucketName: "uploads",
  });
  gfs = gridFSBucket;
  console.log("✅ MongoDB connected. GridFS ready.");
});

// Storage engine
const storage = multer.memoryStorage();
const upload = multer({ storage });

// Routes

// GET / - Basic HTML form
app.get("/", (req, res) => {
  res.send(`
    <style>
      body { font-family: Arial, sans-serif; background: #fafbfc; }
      h2 { font-size: 2em; margin-bottom: 1em; }
      form { margin-top: 2em; }
      input[type="file"] { margin-right: 1em; }
      button { padding: 0.4em 1.2em; font-size: 1em; }
    </style>
    <h2>Upload a File</h2>
    <form action="/upload" method="POST" enctype="multipart/form-data">
      <input type="file" name="file" required />
      <button type="submit">Upload</button>
    </form>
  `);
});

// POST /upload - Upload a file
app.post("/upload", upload.single("file"), async (req, res) => {
  if (!req.file) return res.status(400).send("No file uploaded.");

  try {
    const bucket = new mongoose.mongo.GridFSBucket(conn.db, { bucketName: "uploads" });
    const uploadStream = bucket.openUploadStream(req.file.originalname, {
      contentType: req.file.mimetype,
    });
    uploadStream.end(req.file.buffer);

    uploadStream.on("finish", () => {
      res.status(201).send(`
        <h3>File uploaded successfully</h3>
        <p>Filename: ${req.file.originalname}</p>
        <a href="/files">View All Files</a>
      `);
    });

    uploadStream.on("error", (err) => {
      res.status(500).send("Upload error: " + err.message);
    });
  } catch (err) {
    res.status(500).send("Upload error: " + err.message);
  }
});

// GET /files - List uploaded files
app.get("/files", async (req, res) => {
  const files = await conn.db.collection("uploads.files").find().toArray();
  if (!files || files.length === 0) {
    return res.status(404).send("No files found.");
  }

  let fileList = files
    .map(
      (file) =>
        `<li><strong>${file.filename}</strong> - <a href="/file/${file.filename}">Download</a></li>`
    )
    .join("");

  res.send(`<h2>Uploaded Files</h2><ul>${fileList}</ul>`);
});

// GET /file/:filename - Download file
app.get("/file/:filename", async (req, res) => {
  try {
    const files = await conn.db
      .collection("uploads.files")
      .find({ filename: req.params.filename })
      .toArray();

    if (!files || files.length === 0) {
      return res.status(404).send("File not found.");
    }

    const file = files[0];
    res.set("Content-Type", file.contentType || "application/octet-stream");
    res.set("Content-Disposition", `attachment; filename="${file.filename}"`);

    const downloadStream = gridFSBucket.openDownloadStreamByName(file.filename);
    downloadStream.pipe(res);
  } catch (err) {
    res.status(500).send("Error retrieving file.");
  }
});

// Start server
app.listen(PORT, () => {
  console.log(`🚀 Server running at http://localhost:${PORT}`);
});
